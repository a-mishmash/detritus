package com.github.mishmash.detritus.block;

import java.util.function.Function;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

import static com.github.mishmash.detritus.DetritusMod.MOD_ID;

public class BlockRegistry {

    public static final class_2248 PRIMEVAL_SLAG = register("primeval_slag", class_2248::new, class_4970.class_2251.method_9637().method_9632(4.0f));
    public static final class_2248 EFFLUVIAN_SAND = register("effluvian_sand", class_2248::new, class_4970.class_2251.method_9637().method_9632(4.0f));

    public static void initialize() {}

    /** Registers a block with a corresponding item of the same ID. */
    private static class_2248 register(String path, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        final class_2960 identifier = class_2960.method_60655(MOD_ID, path);
        final class_5321<class_2248> registryKey = class_5321.method_29179(class_7924.field_41254, identifier);

        final class_2248 block = class_2246.method_63053(registryKey, factory, settings);
        class_1802.method_7989(block);
        return block;
    }
}
