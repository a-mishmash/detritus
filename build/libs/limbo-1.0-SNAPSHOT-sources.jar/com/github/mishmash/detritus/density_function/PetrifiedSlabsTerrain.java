package com.github.mishmash.detritus.density_function;

import net.minecraft.class_6910;
import net.minecraft.class_6916;
import net.minecraft.class_7243;

public record PetrifiedSlabsTerrain(class_6910 densityFunction) implements class_6916.class_6932 {

    @Override
    public class_6910 comp_380() {
        return null;
    }

    @Override
    public double method_40520(double density) {
        return 0;
    }

    @Override
    public class_6910 method_40469(class_6915 visitor) {
        return null;
    }

    @Override
    public double comp_377() {
        return 0;
    }

    @Override
    public double comp_378() {
        return 0;
    }

    @Override
    public class_7243<? extends class_6910> method_41062() {
        return null;
    }
}
