package org.example.limbo.client;

import net.fabricmc.api.ClientModInitializer;

public class LimboModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
    }
}
