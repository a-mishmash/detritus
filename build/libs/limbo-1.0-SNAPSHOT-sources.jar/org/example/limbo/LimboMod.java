package org.example.limbo;

import net.fabricmc.api.ModInitializer;

public class LimboMod implements ModInitializer {

    @Override
    public void onInitialize() {
    }
}
