package com.github.mishmash.detritus.density_function;

public class DensityFunctionRegistry {

    public static void initialize() {}
}
