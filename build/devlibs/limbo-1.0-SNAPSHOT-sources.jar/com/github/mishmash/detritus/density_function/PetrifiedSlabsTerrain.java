package com.github.mishmash.detritus.density_function;

import net.minecraft.util.dynamic.CodecHolder;
import net.minecraft.world.gen.densityfunction.DensityFunction;
import net.minecraft.world.gen.densityfunction.DensityFunctionTypes;

public record PetrifiedSlabsTerrain(DensityFunction densityFunction) implements DensityFunctionTypes.Unary {

    @Override
    public DensityFunction input() {
        return null;
    }

    @Override
    public double apply(double density) {
        return 0;
    }

    @Override
    public DensityFunction apply(DensityFunctionVisitor visitor) {
        return null;
    }

    @Override
    public double minValue() {
        return 0;
    }

    @Override
    public double maxValue() {
        return 0;
    }

    @Override
    public CodecHolder<? extends DensityFunction> getCodecHolder() {
        return null;
    }
}
